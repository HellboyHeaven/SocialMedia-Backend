using System.Threading.Tasks;

namespace Application;

public interface IProfileClient
{
    Task<ProfileModel?> GetBriefProfileByIdAsync(Guid userId, CancellationToken cancellationToken);
}
