namespace Application;

public class PostModel
{
    public required Guid Id { get; set; }
    public required ProfileModel Sender { get; set; }
    public required string Content { get; set; }
    public string[] Medias { get; set; } = [];
    public DateTime CreatedAt { get; set; }
    // public uint Likes { get; set; }
    // public uint Comments { get; set; }
    // public bool Liked { get; set; }
}
