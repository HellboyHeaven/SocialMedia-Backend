using MediatR;

namespace Application;

public record CreatePostCommand(Guid UserId, string Content, string[] Medias) : IRequest<Guid>;
