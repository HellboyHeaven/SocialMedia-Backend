using MediatR;
using Core;

namespace Application;

public class CreatePostHandler(IPostStore postStore) : IRequestHandler<CreatePostCommand, Guid>
{
    const string ACTION = "post.create";

    public async Task<Guid> Handle(CreatePostCommand request, CancellationToken cancellationToken)
    {
        var entity = new PostEntity
        {
            SenderId = request.UserId,
            Content = request.Content,
            Medias = request.Medias,
            CreatedAt = DateTime.Now
        };
        var id = await postStore.Create(entity);

        return id;
    }
}
