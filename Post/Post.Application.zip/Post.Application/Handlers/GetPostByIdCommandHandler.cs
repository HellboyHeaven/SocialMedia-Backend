using MediatR;
using Core;

namespace Application;

public class GetPostByIdCommandHandler(IPostStore postStore, IProfileClient client) : IRequestHandler<GetPostByIdCommand, PostModel?>
{
    public async Task<PostModel?> Handle(GetPostByIdCommand request, CancellationToken cancellationToken)
    {
        var entity = await postStore.GetById(request.PostId);
        if (entity == null) return null;
        var profileModel = await client.GetBriefProfileByIdAsync(entity.SenderId, cancellationToken);
        Console.WriteLine(profileModel);
        if (profileModel == null) return null;

        var model = new PostModel
        {
            Id = entity.Id,
            Sender = profileModel,
            Content = entity.Content,
            Medias = entity.Medias,
            CreatedAt = entity.CreatedAt
        };
        return model;
    }


}
